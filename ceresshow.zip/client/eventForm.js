import SimpleSchema from 'simpl-schema';
SimpleSchema.extendOptions(['autoform']);

import { WorkEvents } from "../imports/collections/sensors.js";

WorkEvents.attachSchema(new SimpleSchema({ 
 user: {
 	type: String,
 	label: "User",
 	max: 100,
 },
 work:{
  	type: String,
    label: "Work",
    optional: false,
    allowedValues: ["Fertilizat cu îngrăşăminte organice", 
    				"Dezmiriştit", 
    				"Fertilizat cu îngrăşăminte simple cu fosfor", 
    				"Fertilizat cu îngrăşăminte simple cu potasiu"],
    autoform: {
      options: [
          {label: "Fertilizat cu îngrăşăminte organice", value: "Fertilizat cu îngrăşăminte organice"},
          {label: "Dezmiriştit", value: "Dezmiriştit"},
          {label: "Fertilizat cu îngrăşăminte simple cu fosfor", value: "Fertilizat cu îngrăşăminte simple cu fosfor"},
          {label: "Fertilizat cu îngrăşăminte simple cu potasiu", value: "Fertilizat cu îngrăşăminte simple cu potasiu"}
      ]
    }	
 },
 event_content: {
 	type: String,
    label: "Event Content",
    max: 300,
    autoform: {
        type: 'text'
    }
 },
 created_at: {
    type: Date,
    label: "Date",
    autoform: {
      afFieldInput: {
      	value: new Date(),
        type: Date,
      }
    }
  }
},{ tracker: Tracker }));


Template.eventForm.helpers({
 currentUser: function () {
        return Meteor.user().username;
    },
  workSchema:function() {
    return WorkEvents;
  }
});

