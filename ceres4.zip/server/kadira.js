//Kadira.connect('eLMbqXrwCf7N8rhvr', '79e5fa34-9f62-44b3-83ce-594e9a53c8dc');//test
//Kadira.connect('CvsxZdF3NrS9ahtMM', 'f57ec0e6-6d1c-4df4-ba7c-754e3d1bbf6d');//live
