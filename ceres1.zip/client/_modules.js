import { Meteor } from 'meteor/meteor';
import { Modules } from 'meteor/modules';
/*Modules.client = {};*/