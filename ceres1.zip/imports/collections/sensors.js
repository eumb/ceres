import { Mongo } from "meteor/mongo";

export const Sensors = new Mongo.Collection("sensorvalues");
export const SensorNames = new Mongo.Collection("sensornames");
export const SensorTelemetry = new Mongo.Collection("sensortelemetries");
export const DeviceDetails =new Mongo.Collection("devicedatas");
export const WorkEvents = new Mongo.Collection("events");


if (Meteor.isServer) {

  Sensors._ensureIndex({ "nodename": 1});


  Meteor.publish("sensor_5", function sensorsPublication() {
  self = this;
  console.log("subscribed to Sensor_5");
  sensor_5=Sensors.aggregate([
      { $match: {
            nodename: "Senzor_5",
            soil_t:{$exists:true}
        }
      },
      {$sort : {"created_at" : -1}},
      {$group: {
           _id: {
            year : { $year : "$created_at" },        
            month : { $month : "$created_at" },        
            day : { $dayOfMonth : "$created_at" }
          },
             averageDayValue: {$avg: "$soil_t"}
       }
      },
       {$sort : {"_id" : -1}},
      
    ]);

 //console.log(sensor_5)
_(sensor_5).each(function(sensor_5) {
      self.added("sensor_5", Random.id(), {
        created_at: sensor_5._id,
        soil_t:sensor_5.averageDayValue

    });
});
 self.ready();
});


  Meteor.publish("S5", function sensorsPublication() {
    console.log("subscribed to S5");
        self=this;
        soilDatas = Sensors.aggregate([
      { $match: { nodename: "Senzor_5" }},
      //{$sort : {"created_at" : -1}},
        {
          $project: {
            'created_at': 1,            
            'soil_t':1 ,
            'w_1':1,
            'w_2':1,
            'w_3':1,
            'nodename':1
          }
        }
      ]);
      //console.log(soilDatas)
    _(soilDatas).each(function(soilData) {
      self.added("sensorvalue", Random.id(), {
        created_at:soilData.created_at,
        soil_t: soilData.soil_t,
        w_1:soilData.w_1,
        w_2:soilData.w_2,
        w_3:soilData.w_3,
        nodename: soilData.nodename
      });
    });
    self.ready();
      //console.log(soilDatas);
      //return soilData;
  });


 Meteor.publish("sensordata", function sensorsPublication(senzor) {
    console.log("subscribed to sensordata");
        self=this;
        sensorDatas = Sensors.aggregate([
      { $match: { nodename: senzor }},
      //{$sort : {"created_at" : -1}},
        {
          $project: {
            'created_at': 1,            
            'soil_t':1 ,
            'w_1':1,
            'w_2':1,
            'w_3':1,

            'nodename':1
          }
        }
      ]);
      //console.log(sensorDatas)
    _(sensorDatas).each(function(sensorData) {
      self.added("sensordata", Random.id(), {
        created_at:sensorData.created_at,
        soil_t: sensorData.soil_t,
        w_1:sensorData.w_1,
        w_2:sensorData.w_2,
        w_3:sensorData.w_3,
        nodename: sensorData.nodename
      });
    });
    self.ready();
      //console.log(soilDatas);
      //return soilData;
  });
  

 Meteor.publish('events', function eventsPublication() {
      console.log("subscribed to events");
      //console.log(WorkEvents.find({}, { sort: { created_at: -1 } }).fetch())
      return WorkEvents.find({}, { sort: { created_at: -1 } });
   });
  
Meteor.publish("devicedatas", function sensorsPublication() {
    console.log("subscribed to devicedatas");
    return DeviceDetails.find({});
  });

  Meteor.publish("sensortelemetries", function sensorsPublication() {
    console.log("subscribed to sensortelemetries");
    return SensorTelemetry.find({}, { sort: { created_at: -1 } });
  });
  Meteor.publish("sensornames", function sensorsPublication() {
    console.log("subscribed to sensornames");
    return SensorNames.find({});
  });




  Meteor.publish("sensorvalues", function sensorsPublication(senzor) {
    console.log("subscribed to sensorvalues");
    //var offsetEESTmillisec =moment.tz.zone("Europe/Bucharest").offset(moment()) * 60 * 1000;
 
   
 /*   yesterday = moment().subtract(1,'days');
    console.log(yesterday);
    if (senzor==="Senzor_5")
    {
      return Sensors.find(
      { nodename: senzor , updatedAt: { $gte: yesterday }},
      { sort: { created_at: -1 }}
    )
    }else*/
    if (senzor==="Senzor_5"){
      return Sensors.find(
      {nodename:senzor},
      { sort: { created_at: -1 },limit:5000}
    );
    } else 
    return Sensors.find(
      {nodename:senzor},
      { sort: { created_at: -1 }}
    );
  });
  Meteor.publish("sensorvalue", function sensorsPublication(senzor) {
    self = this;
    var offsetEESTmillisec =
      moment.tz.zone("Europe/Bucharest").offset(moment()) * 60 * 1000;    ///compensate for  TZ from UTC  // must change to EET on wintertime
    //console.log(offsetEESTmillisec);
    soilDatas = Sensors.aggregate([
      { $match: { nodename: senzor, soil_t: { $exists: true }, updatedAt : { $gte : new Date("2017-04-14T21:00:00Z") } } },
      //{$sort : {"created_at" : -1}},
        {
          $project: {
            'hour': { $hour: [{ $subtract: ["$updatedAt", offsetEESTmillisec] }] },
            'day': {$dayOfMonth: [{ $subtract: ["$updatedAt", offsetEESTmillisec] }]},
            'month': { $month: [{ $subtract: ["$updatedAt", offsetEESTmillisec] }] },
            'soil_t':1 ,
            'nodename':1
          }
        }
      ]);
    _(soilDatas).each(function(soilData) {
      self.added("sensorvalue", Random.id(), {
        hour: soilData.hour,
        month: soilData.month,
        day: soilData.day,
        temp: soilData.soil_t,
        nodename: soilData.nodename
      });
    });
    self.ready();
      //console.log(soilDatas);
      //return soilData;
  });

  
}
